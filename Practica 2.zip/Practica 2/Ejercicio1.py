# Ejercicio 1: Crear y Acceder a Elementos 
# Crea una lista llamada colores que contenga tres colores de tu elección.  
# Luego, imprime el primer y el último color de la lista.
 
colores = ["rojo", "verde", "azul"]

print('Lista: ',colores)
print("Primer color:", colores[0])
print("Último color:", colores[-1])

