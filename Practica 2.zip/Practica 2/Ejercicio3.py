# Ejercicio 3: Agregar Elementos 
# Crea una lista vacía llamada animales.
# Luego, agrega tres animales a la lista usando el método append() y uno más en la segunda posición usando insert().
# Finalmente, imprime la lista completa. 

animales = []  
animales.append("perro")
animales.append("gato")
animales.append("conejo")
animales.insert(1, "pajaro") 

print("Lista de animales:", animales)