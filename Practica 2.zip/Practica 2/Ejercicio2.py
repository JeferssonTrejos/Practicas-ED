# Ejercicio 2: Modificar Elementos 
# Crea una lista llamada numeros con los valores [10, 20, 30, 40, 50]. 
# Cambia el  tercer valor de la lista por 35 y luego imprime la lista modificada.
 
numeros = [10, 20, 30, 40, 50]
print("Lista original:\n", numeros)

numeros[2] = 35
print("Lista modificada:\n", numeros)
